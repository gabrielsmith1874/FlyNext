#!/bin/bash

# Start the backend server
echo "Starting FlyNext backend server..."
npm run dev